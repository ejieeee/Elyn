// Real Web Audio API Sound Synthesizer & Ambient Soundscape Generator
import { Track } from '../types';

class BotanicalSoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private ambientGain: GainNode | null = null;
  private analyser: AnalyserNode | null = null;

  // Music generative nodes
  private isMusicPlaying: boolean = false;
  private currentTrack: Track | null = null;
  private musicIntervalId: number | null = null;
  private playbackTime: number = 0;
  private onTimeUpdateCallback: ((time: number) => void) | null = null;
  private onTrackEndedCallback: (() => void) | null = null;

  // Soundscape ambient nodes
  private ambientSources: Map<string, { gain: GainNode; stop: () => void }> = new Map();

  constructor() {
    // AudioContext will be initialized on first user gesture
  }

  private initContext() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioContextClass();

      // Master Gain
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.85, this.ctx.currentTime);

      // Music Channel Gain
      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.setValueAtTime(0.8, this.ctx.currentTime);
      this.musicGain.connect(this.masterGain);

      // Ambient Channel Gain
      this.ambientGain = this.ctx.createGain();
      this.ambientGain.gain.setValueAtTime(0.7, this.ctx.currentTime);
      this.ambientGain.connect(this.masterGain);

      // Analyser for ink-wash visualizer
      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 256;
      this.analyser.smoothingTimeConstant = 0.85;

      this.masterGain.connect(this.analyser);
      this.analyser.connect(this.ctx.destination);
    }

    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setCallbacks(onTimeUpdate: (time: number) => void, onTrackEnded: () => void) {
    this.onTimeUpdateCallback = onTimeUpdate;
    this.onTrackEndedCallback = onTrackEnded;
  }

  public setMasterVolume(val: number) {
    this.initContext();
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(Math.max(0, Math.min(1, val)), this.ctx.currentTime, 0.05);
    }
  }

  public playTrack(track: Track, startTime: number = 0) {
    this.initContext();
    this.stopMusic();

    this.currentTrack = track;
    this.playbackTime = startTime;
    this.isMusicPlaying = true;

    // Track progression timer
    this.musicIntervalId = window.setInterval(() => {
      if (this.isMusicPlaying && this.currentTrack) {
        this.playbackTime += 1;
        if (this.onTimeUpdateCallback) {
          this.onTimeUpdateCallback(this.playbackTime);
        }

        if (this.playbackTime >= this.currentTrack.duration) {
          this.stopMusic();
          if (this.onTrackEndedCallback) {
            this.onTrackEndedCallback();
          }
        }
      }
    }, 1000);

    // Start playing acoustic chord arpeggio based on track key & mood
    this.startAcousticPattern(track);
  }

  public pauseTrack() {
    this.isMusicPlaying = false;
    if (this.musicIntervalId !== null) {
      clearInterval(this.musicIntervalId);
      this.musicIntervalId = null;
    }
  }

  public resumeTrack() {
    if (this.currentTrack && !this.isMusicPlaying) {
      this.playTrack(this.currentTrack, this.playbackTime);
    }
  }

  public seek(seconds: number) {
    this.playbackTime = Math.max(0, Math.min(seconds, this.currentTrack ? this.currentTrack.duration : seconds));
    if (this.onTimeUpdateCallback) {
      this.onTimeUpdateCallback(this.playbackTime);
    }
  }

  public stopMusic() {
    this.isMusicPlaying = false;
    if (this.musicIntervalId !== null) {
      clearInterval(this.musicIntervalId);
      this.musicIntervalId = null;
    }
  }

  public getAnalyserData(): Uint8Array | null {
    if (!this.analyser) return null;
    const bufferLength = this.analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    this.analyser.getByteFrequencyData(dataArray);
    return dataArray;
  }

  public getTimeDomainData(): Uint8Array | null {
    if (!this.analyser) return null;
    const bufferLength = this.analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    this.analyser.getByteTimeDomainData(dataArray);
    return dataArray;
  }

  // Synthesize acoustic felt piano and cello arpeggios
  private startAcousticPattern(track: Track) {
    if (!this.ctx || !this.musicGain) return;

    // Frequencies mapped to gentle meditative modes
    const keyMap: Record<string, number[]> = {
      'G major': [196.00, 246.94, 293.66, 392.00, 493.88, 587.33], // G3, B3, D4, G4, B4, D5
      'E minor': [164.81, 196.00, 246.94, 329.63, 392.00, 493.88], // E3, G3, B3, E4, G4, B4
      'C major': [130.81, 196.00, 261.63, 329.63, 392.00, 523.25], // C3, G3, C4, E4, G4, C5
      'D minor': [146.83, 220.00, 293.66, 349.23, 440.00, 587.33], // D3, A3, D4, F4, A4, D5
      'D pentatonic': [146.83, 164.81, 220.00, 293.66, 329.63, 440.00], // D3, E3, A3, D4, E4, A4
      'default': [174.61, 220.00, 261.63, 349.23, 440.00, 523.25], // F3, A3, C4, F4, A4, C5
    };

    const notes = keyMap[track.key] || keyMap['default'];
    let noteIndex = 0;

    const playNextNote = () => {
      if (!this.isMusicPlaying || !this.ctx || !this.musicGain) return;

      const baseFreq = notes[noteIndex % notes.length];
      const time = this.ctx.currentTime;

      // Primary tone: Soft felt piano / cello harmonic
      const osc1 = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const filter = this.ctx.createBiquadFilter();
      const noteGain = this.ctx.createGain();

      osc1.type = 'triangle';
      osc1.frequency.setValueAtTime(baseFreq, time);

      // Subtle detune for acoustic warmth
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(baseFreq * 0.5, time); // Sub-octave resonance

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(800, time);
      filter.frequency.exponentialRampToValueAtTime(220, time + 2.5);

      // Felt attack and long acoustic decay
      noteGain.gain.setValueAtTime(0.001, time);
      noteGain.gain.linearRampToValueAtTime(0.22, time + 0.08);
      noteGain.gain.exponentialRampToValueAtTime(0.0001, time + 3.2);

      osc1.connect(filter);
      osc2.connect(filter);
      filter.connect(noteGain);
      noteGain.connect(this.musicGain);

      osc1.start(time);
      osc2.start(time);
      osc1.stop(time + 3.4);
      osc2.stop(time + 3.4);

      noteIndex = (noteIndex + 1 + Math.floor(Math.random() * 2)) % notes.length;

      // Schedule next note with calm organic timing
      const stepDuration = (60 / (track.bpm || 56)) * 1000 * (Math.random() > 0.4 ? 1.5 : 2.0);
      if (this.isMusicPlaying) {
        setTimeout(playNextNote, stepDuration);
      }
    };

    playNextNote();
  }

  // Update or toggle ambient soundscape layers
  public updateAmbientLayer(layerId: string, enabled: boolean, volume: number) {
    this.initContext();
    if (!this.ctx || !this.ambientGain) return;

    const existing = this.ambientSources.get(layerId);

    if (!enabled || volume <= 0.01) {
      if (existing) {
        existing.gain.gain.setTargetAtTime(0.0001, this.ctx.currentTime, 0.2);
        setTimeout(() => {
          existing.stop();
          this.ambientSources.delete(layerId);
        }, 300);
      }
      return;
    }

    if (existing) {
      existing.gain.gain.setTargetAtTime(volume * 0.5, this.ctx.currentTime, 0.1);
      return;
    }

    // Create new ambient generator for layerId
    const gainNode = this.ctx.createGain();
    gainNode.gain.setValueAtTime(0.001, this.ctx.currentTime);
    gainNode.gain.setTargetAtTime(volume * 0.5, this.ctx.currentTime, 0.5);
    gainNode.connect(this.ambientGain);

    let stopFunc = () => {};

    if (layerId === 'layer-canopy-wind') {
      stopFunc = this.createWindNoise(gainNode);
    } else if (layerId === 'layer-greenhouse-rain') {
      stopFunc = this.createRainNoise(gainNode);
    } else if (layerId === 'layer-water-stream') {
      stopFunc = this.createWaterStream(gainNode);
    } else if (layerId === 'layer-paper-rustle') {
      stopFunc = this.createPaperRustle(gainNode);
    } else if (layerId === 'layer-dusk-cicada') {
      stopFunc = this.createCicadaSound(gainNode);
    }

    this.ambientSources.set(layerId, { gain: gainNode, stop: stopFunc });
  }

  private createWindNoise(targetGain: GainNode): () => void {
    if (!this.ctx) return () => {};
    // White noise generator passed through moving bandpass filter
    const bufferSize = this.ctx.sampleRate * 2;
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const whiteNoise = this.ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;
    whiteNoise.loop = true;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(260, this.ctx.currentTime);

    // LFO to simulate gentle gusts
    const lfo = this.ctx.createOscillator();
    const lfoGain = this.ctx.createGain();
    lfo.frequency.setValueAtTime(0.18, this.ctx.currentTime);
    lfoGain.gain.setValueAtTime(140, this.ctx.currentTime);

    lfo.connect(lfoGain);
    lfoGain.connect(filter.frequency);

    whiteNoise.connect(filter);
    filter.connect(targetGain);

    whiteNoise.start();
    lfo.start();

    return () => {
      try {
        whiteNoise.stop();
        lfo.stop();
        whiteNoise.disconnect();
        lfo.disconnect();
      } catch {
        // safe ignore
      }
    };
  }

  private createRainNoise(targetGain: GainNode): () => void {
    if (!this.ctx) return () => {};
    const bufferSize = this.ctx.sampleRate * 2;
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const whiteNoise = this.ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;
    whiteNoise.loop = true;

    const bandpass = this.ctx.createBiquadFilter();
    bandpass.type = 'bandpass';
    bandpass.frequency.setValueAtTime(1200, this.ctx.currentTime);
    bandpass.Q.setValueAtTime(1.2, this.ctx.currentTime);

    whiteNoise.connect(bandpass);
    bandpass.connect(targetGain);
    whiteNoise.start();

    return () => {
      try {
        whiteNoise.stop();
        whiteNoise.disconnect();
      } catch {
        // safe ignore
      }
    };
  }

  private createWaterStream(targetGain: GainNode): () => void {
    if (!this.ctx) return () => {};
    const bufferSize = this.ctx.sampleRate * 2;
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const source = this.ctx.createBufferSource();
    source.buffer = noiseBuffer;
    source.loop = true;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(650, this.ctx.currentTime);
    filter.Q.setValueAtTime(3.5, this.ctx.currentTime);

    source.connect(filter);
    filter.connect(targetGain);
    source.start();

    return () => {
      try {
        source.stop();
        source.disconnect();
      } catch {
        // safe ignore
      }
    };
  }

  private createPaperRustle(targetGain: GainNode): () => void {
    if (!this.ctx) return () => {};
    const bufferSize = this.ctx.sampleRate * 2;
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = (Math.random() * 2 - 1) * 0.4;
    }

    const source = this.ctx.createBufferSource();
    source.buffer = noiseBuffer;
    source.loop = true;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.setValueAtTime(3200, this.ctx.currentTime);

    source.connect(filter);
    filter.connect(targetGain);
    source.start();

    return () => {
      try {
        source.stop();
        source.disconnect();
      } catch {
        // safe ignore
      }
    };
  }

  private createCicadaSound(targetGain: GainNode): () => void {
    if (!this.ctx) return () => {};
    const osc = this.ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(4500, this.ctx.currentTime);

    const amp = this.ctx.createGain();
    amp.gain.setValueAtTime(0.08, this.ctx.currentTime);

    const lfo = this.ctx.createOscillator();
    lfo.frequency.setValueAtTime(3.2, this.ctx.currentTime);
    lfo.connect(amp.gain);

    osc.connect(amp);
    amp.connect(targetGain);

    osc.start();
    lfo.start();

    return () => {
      try {
        osc.stop();
        lfo.stop();
        osc.disconnect();
        lfo.disconnect();
      } catch {
        // safe ignore
      }
    };
  }
}

export const soundEngine = new BotanicalSoundEngine();
