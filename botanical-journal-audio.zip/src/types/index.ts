export interface Track {
  id: string;
  albumId: string;
  title: string;
  movementNumber: string; // e.g. "Mov. I", "Op. 12"
  duration: number; // in seconds
  specimenName: string;
  latinName: string;
  specimenCollectionDate?: string;
  location?: string;
  instrumentation: string[];
  bpm: number;
  key: string;
  curatorNotes: string;
  tags: string[];
  isFavorite?: boolean;
}

export interface Album {
  id: string;
  title: string;
  subtitle: string;
  catalogNumber: string; // e.g. "CAT. BJ-1894-IV"
  releaseEra: string;
  collection: string; // e.g. "Cryptogams & Wet Mosses"
  shelf: string; // e.g. "Pressed Specimens", "Moss & Fern Sonatas"
  coverUrl: string;
  specimenPlateUrl: string;
  primaryBotanicalSubject: string;
  latinBinomial: string;
  herbariumLocation: string;
  collector: string;
  yearPreserved: number;
  description: string;
  curatorStamp: string;
  tracks: Track[];
}

export interface MarginaliaEntry {
  id: string;
  trackId: string;
  trackTitle: string;
  timestamp: string;
  sealType: 'fern' | 'ginkgo' | 'rose' | 'lavender' | 'wax';
  content: string;
  pencilShade: string;
}

export interface SoundscapeLayer {
  id: string;
  name: string;
  japaneseTitle?: string;
  volume: number; // 0 to 1
  enabled: boolean;
  colorWash: string;
  iconName: string;
  description: string;
}

export type ActiveView = 'journal' | 'herbarium' | 'soundscape' | 'marginalia';
