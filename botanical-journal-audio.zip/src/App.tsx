/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { 
  BOTANICAL_ALBUMS, 
  INITIAL_SOUNDSCAPE_LAYERS, 
  INITIAL_MARGINALIA 
} from './data/botanicalData';
import { Album, Track, SoundscapeLayer, MarginaliaEntry, ActiveView } from './types';
import { soundEngine } from './services/soundEngine';
import { TheMargin } from './components/TheMargin';
import { TheEasel } from './components/TheEasel';
import { AlbumJournalView } from './components/AlbumJournalView';
import { HerbariumLibraryView } from './components/HerbariumLibraryView';
import { SoundscapeMixerView } from './components/SoundscapeMixerView';
import { MarginaliaJournalView } from './components/MarginaliaJournalView';
import { SpecimenInspectModal } from './components/SpecimenInspectModal';

export default function App() {
  const [albums, setAlbums] = useState<Album[]>(BOTANICAL_ALBUMS);
  const [currentAlbum, setCurrentAlbum] = useState<Album>(BOTANICAL_ALBUMS[0]);
  const [currentTrack, setCurrentTrack] = useState<Track | null>(BOTANICAL_ALBUMS[0].tracks[0]);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [volume, setVolume] = useState<number>(0.85);

  const [activeView, setActiveView] = useState<ActiveView>('journal');
  const [isMarginCollapsed, setIsMarginCollapsed] = useState<boolean>(false);
  const [selectedShelf, setSelectedShelf] = useState<string>('all');
  const [selectedTag, setSelectedTag] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const [soundscapeLayers, setSoundscapeLayers] = useState<SoundscapeLayer[]>(INITIAL_SOUNDSCAPE_LAYERS);
  const [marginaliaEntries, setMarginaliaEntries] = useState<MarginaliaEntry[]>(() => {
    try {
      const saved = localStorage.getItem('botanical_marginalia_notes');
      return saved ? JSON.parse(saved) : INITIAL_MARGINALIA;
    } catch {
      return INITIAL_MARGINALIA;
    }
  });

  const [inspectingAlbum, setInspectingAlbum] = useState<Album | null>(null);

  // Synchronize sound engine callbacks
  useEffect(() => {
    soundEngine.setCallbacks(
      (time: number) => {
        setCurrentTime(time);
      },
      () => {
        handleNextTrack();
      }
    );
  }, [currentAlbum, currentTrack]);

  // Persist marginalia
  useEffect(() => {
    try {
      localStorage.setItem('botanical_marginalia_notes', JSON.stringify(marginaliaEntries));
    } catch {
      // ignore in iframe
    }
  }, [marginaliaEntries]);

  // Next Track Logic
  const handleNextTrack = useCallback(() => {
    if (!currentAlbum || !currentTrack) return;
    const currentIndex = currentAlbum.tracks.findIndex((t) => t.id === currentTrack.id);
    if (currentIndex >= 0 && currentIndex < currentAlbum.tracks.length - 1) {
      const next = currentAlbum.tracks[currentIndex + 1];
      setCurrentTrack(next);
      setCurrentTime(0);
      soundEngine.playTrack(next, 0);
      setIsPlaying(true);
    } else {
      // Jump to next album in collection
      const currentAlbumIndex = albums.findIndex((a) => a.id === currentAlbum.id);
      const nextAlbumIndex = (currentAlbumIndex + 1) % albums.length;
      const nextAlbum = albums[nextAlbumIndex];
      setCurrentAlbum(nextAlbum);
      const firstTrack = nextAlbum.tracks[0];
      setCurrentTrack(firstTrack);
      setCurrentTime(0);
      soundEngine.playTrack(firstTrack, 0);
      setIsPlaying(true);
    }
  }, [albums, currentAlbum, currentTrack]);

  // Previous Track Logic
  const handlePrevTrack = useCallback(() => {
    if (!currentAlbum || !currentTrack) return;
    if (currentTime > 4) {
      // If played more than 4 seconds, restart current movement
      setCurrentTime(0);
      soundEngine.seek(0);
      return;
    }
    const currentIndex = currentAlbum.tracks.findIndex((t) => t.id === currentTrack.id);
    if (currentIndex > 0) {
      const prev = currentAlbum.tracks[currentIndex - 1];
      setCurrentTrack(prev);
      setCurrentTime(0);
      soundEngine.playTrack(prev, 0);
      setIsPlaying(true);
    } else {
      const currentAlbumIndex = albums.findIndex((a) => a.id === currentAlbum.id);
      const prevAlbumIndex = (currentAlbumIndex - 1 + albums.length) % albums.length;
      const prevAlbum = albums[prevAlbumIndex];
      setCurrentAlbum(prevAlbum);
      const lastTrack = prevAlbum.tracks[prevAlbum.tracks.length - 1];
      setCurrentTrack(lastTrack);
      setCurrentTime(0);
      soundEngine.playTrack(lastTrack, 0);
      setIsPlaying(true);
    }
  }, [albums, currentAlbum, currentTrack, currentTime]);

  // Master Play / Pause
  const handlePlayPause = () => {
    if (!currentTrack) {
      if (currentAlbum && currentAlbum.tracks.length > 0) {
        handlePlayTrack(currentAlbum.tracks[0]);
      }
      return;
    }

    if (isPlaying) {
      soundEngine.pauseTrack();
      setIsPlaying(false);
    } else {
      soundEngine.resumeTrack();
      setIsPlaying(true);
    }
  };

  // Play a specific track
  const handlePlayTrack = (track: Track) => {
    if (currentTrack?.id === track.id && isPlaying) {
      soundEngine.pauseTrack();
      setIsPlaying(false);
      return;
    }

    // Locate track album
    const parentAlbum = albums.find((a) => a.id === track.albumId);
    if (parentAlbum) {
      setCurrentAlbum(parentAlbum);
    }

    setCurrentTrack(track);
    setCurrentTime(0);
    soundEngine.playTrack(track, 0);
    setIsPlaying(true);
  };

  // Play full album from start
  const handlePlayAlbum = (album: Album) => {
    setCurrentAlbum(album);
    if (album.tracks.length > 0) {
      handlePlayTrack(album.tracks[0]);
    }
  };

  // Seek bar
  const handleSeek = (seconds: number) => {
    setCurrentTime(seconds);
    soundEngine.seek(seconds);
  };

  // Master Volume
  const handleVolumeChange = (val: number) => {
    setVolume(val);
    soundEngine.setMasterVolume(val);
  };

  // Toggle favorite bookmark
  const handleToggleFavorite = (trackId: string) => {
    setAlbums((prevAlbums) =>
      prevAlbums.map((album) => ({
        ...album,
        tracks: album.tracks.map((t) =>
          t.id === trackId ? { ...t, isFavorite: !t.isFavorite } : t
        ),
      }))
    );

    if (currentTrack && currentTrack.id === trackId) {
      setCurrentTrack((prev) => (prev ? { ...prev, isFavorite: !prev.isFavorite } : null));
    }
  };

  // Ambient Layer Toggles
  const handleToggleLayer = (layerId: string) => {
    setSoundscapeLayers((prevLayers) =>
      prevLayers.map((layer) => {
        if (layer.id === layerId) {
          const newEnabled = !layer.enabled;
          soundEngine.updateAmbientLayer(layerId, newEnabled, layer.volume);
          return { ...layer, enabled: newEnabled };
        }
        return layer;
      })
    );
  };

  // Ambient Layer Volume
  const handleChangeLayerVolume = (layerId: string, layerVol: number) => {
    setSoundscapeLayers((prevLayers) =>
      prevLayers.map((layer) => {
        if (layer.id === layerId) {
          const autoEnable = layerVol > 0.01;
          soundEngine.updateAmbientLayer(layerId, autoEnable, layerVol);
          return { ...layer, volume: layerVol, enabled: autoEnable };
        }
        return layer;
      })
    );
  };

  // Reset Ambient Layers
  const handleResetLayers = () => {
    soundscapeLayers.forEach((layer) => {
      soundEngine.updateAmbientLayer(layer.id, false, 0);
    });
    setSoundscapeLayers(
      INITIAL_SOUNDSCAPE_LAYERS.map((l) => ({
        ...l,
        enabled: l.id === 'layer-canopy-wind',
        volume: l.id === 'layer-canopy-wind' ? 0.35 : 0.0,
      }))
    );
  };

  // Presets
  const handleApplyPreset = (presetName: string) => {
    let newLayers = [...soundscapeLayers];
    if (presetName === 'rainy-greenhouse') {
      newLayers = newLayers.map((l) => ({
        ...l,
        enabled: l.id === 'layer-greenhouse-rain' || l.id === 'layer-canopy-wind',
        volume: l.id === 'layer-greenhouse-rain' ? 0.6 : l.id === 'layer-canopy-wind' ? 0.3 : 0,
      }));
    } else if (presetName === 'kyoto-calligraphy') {
      newLayers = newLayers.map((l) => ({
        ...l,
        enabled: l.id === 'layer-water-stream' || l.id === 'layer-paper-rustle',
        volume: l.id === 'layer-water-stream' ? 0.45 : l.id === 'layer-paper-rustle' ? 0.35 : 0,
      }));
    } else if (presetName === 'alpine-canopy') {
      newLayers = newLayers.map((l) => ({
        ...l,
        enabled: l.id === 'layer-canopy-wind' || l.id === 'layer-dusk-cicada',
        volume: l.id === 'layer-canopy-wind' ? 0.5 : l.id === 'layer-dusk-cicada' ? 0.25 : 0,
      }));
    } else {
      // all clear
      newLayers = newLayers.map((l) => ({ ...l, enabled: false, volume: 0 }));
    }

    newLayers.forEach((l) => {
      soundEngine.updateAmbientLayer(l.id, l.enabled, l.volume);
    });
    setSoundscapeLayers(newLayers);
  };

  // Add Marginalia Entry
  const handleAddMarginalia = (
    trackId: string,
    content: string,
    seal: 'fern' | 'ginkgo' | 'rose' | 'lavender' | 'wax'
  ) => {
    const allTracks = albums.flatMap((a) => a.tracks);
    const target = allTracks.find((t) => t.id === trackId);
    const title = target ? target.title : 'General Folio Impression';

    const newEntry: MarginaliaEntry = {
      id: `note-${Date.now()}`,
      trackId,
      trackTitle: title,
      timestamp: new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
      sealType: seal,
      content,
      pencilShade: '#443C35',
    };

    setMarginaliaEntries((prev) => [newEntry, ...prev]);
  };

  // Delete Marginalia
  const handleDeleteMarginalia = (id: string) => {
    setMarginaliaEntries((prev) => prev.filter((e) => e.id !== id));
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#F5F0E6] text-[#443C35] font-sans antialiased">
      {/* Left Canvas: The Margin (Collapsible navigation) */}
      <TheMargin
        activeView={activeView}
        setActiveView={setActiveView}
        selectedShelf={selectedShelf}
        setSelectedShelf={setSelectedShelf}
        selectedTag={selectedTag}
        setSelectedTag={setSelectedTag}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        isCollapsed={isMarginCollapsed}
        setIsCollapsed={setIsMarginCollapsed}
        currentAlbumTitle={currentAlbum.title}
        totalNotesCount={marginaliaEntries.length}
      />

      {/* Center & Main Content Canvas: The Leaf */}
      <div className="flex-1 flex flex-col h-full min-w-0 overflow-hidden relative">
        {/* Main scrollable body */}
        <main className="flex-1 overflow-y-auto pb-6">
          {activeView === 'journal' && (
            <AlbumJournalView
              album={currentAlbum}
              currentTrack={currentTrack}
              isPlaying={isPlaying}
              onPlayTrack={handlePlayTrack}
              onToggleFavorite={handleToggleFavorite}
              onOpenSpecimenModal={() => setInspectingAlbum(currentAlbum)}
              onAddMarginalia={handleAddMarginalia}
            />
          )}

          {activeView === 'herbarium' && (
            <HerbariumLibraryView
              albums={albums}
              selectedShelf={selectedShelf}
              selectedTag={selectedTag}
              searchQuery={searchQuery}
              onSelectAlbum={(alb) => {
                setCurrentAlbum(alb);
                setActiveView('journal');
              }}
              onPlayAlbum={handlePlayAlbum}
              onInspectSpecimen={(alb) => setInspectingAlbum(alb)}
            />
          )}

          {activeView === 'soundscape' && (
            <SoundscapeMixerView
              layers={soundscapeLayers}
              onToggleLayer={handleToggleLayer}
              onChangeVolume={handleChangeLayerVolume}
              onResetLayers={handleResetLayers}
              onApplyPreset={handleApplyPreset}
            />
          )}

          {activeView === 'marginalia' && (
            <MarginaliaJournalView
              entries={marginaliaEntries}
              albums={albums}
              onAddEntry={handleAddMarginalia}
              onDeleteEntry={handleDeleteMarginalia}
            />
          )}
        </main>

        {/* Bottom Rail: The Easel (Anchored 92px floating player) */}
        <TheEasel
          currentTrack={currentTrack}
          currentAlbum={currentAlbum}
          isPlaying={isPlaying}
          currentTime={currentTime}
          duration={currentTrack ? currentTrack.duration : 0}
          volume={volume}
          onPlayPause={handlePlayPause}
          onSeek={handleSeek}
          onVolumeChange={handleVolumeChange}
          onNextTrack={handleNextTrack}
          onPrevTrack={handlePrevTrack}
          onToggleFavorite={handleToggleFavorite}
          onOpenSpecimenModal={() => setInspectingAlbum(currentAlbum)}
        />
      </div>

      {/* Archival Specimen Drawer Modal */}
      {inspectingAlbum && (
        <SpecimenInspectModal
          album={inspectingAlbum}
          onClose={() => setInspectingAlbum(null)}
          onPlayAlbum={handlePlayAlbum}
        />
      )}
    </div>
  );
}
