import React from 'react';
import { X, Sparkles, MapPin, Calendar, User, Compass, BookOpen } from 'lucide-react';
import { Album } from '../types';

interface SpecimenInspectModalProps {
  album: Album | null;
  onClose: () => void;
  onPlayAlbum: (album: Album) => void;
}

export const SpecimenInspectModal: React.FC<SpecimenInspectModalProps> = ({
  album,
  onClose,
  onPlayAlbum,
}) => {
  if (!album) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-[#211a14]/50 backdrop-blur-xs animate-fade-in">
      <div 
        className="raised-journal w-full max-w-3xl rounded-xl overflow-hidden max-h-[90vh] flex flex-col relative text-[#443C35]"
        style={{
          boxShadow: '0 20px 40px -8px rgba(68, 60, 53, 0.25), 0 8px 16px -4px rgba(68, 60, 53, 0.15)',
        }}
      >
        {/* Modal Top Bar */}
        <div className="px-6 py-4 border-b border-[#443C35]/12 flex items-center justify-between bg-[#FBF8F1]">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#B97862]" />
            <span className="font-mono text-xs uppercase tracking-widest text-[#89977D]">
              Archivum Botanicum Folio • {album.catalogNumber}
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-[#89977D]/15 text-[#81776D] hover:text-[#443C35] transition-colors cursor-pointer"
            title="Close Drawer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6 bg-[#FBF8F1]">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-7 items-center">
            {/* Specimen Plate with 6px Ivory Mat */}
            <div 
              className="relative aspect-4/3 sm:aspect-square w-full rounded-sm overflow-hidden"
              style={{
                boxShadow: '0 0 0 6px #F5F0E6, 0 8px 24px rgba(68, 60, 53, 0.16)'
              }}
            >
              <img 
                src={album.specimenPlateUrl} 
                alt={album.primaryBotanicalSubject}
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-2 left-2 bg-[#FBF8F1]/90 backdrop-blur-xs px-2 py-0.5 rounded text-[10px] font-mono border border-[#443C35]/10">
                SPECIMEN REF. {album.catalogNumber}
              </div>
            </div>

            {/* Specimen Field Documentation */}
            <div className="space-y-4">
              <div>
                <span className="text-[11px] font-mono uppercase tracking-wider text-[#89977D]">
                  Taxonomic Classification
                </span>
                <h3 className="font-serif text-2xl font-medium text-[#443C35] mt-0.5 leading-tight">
                  {album.primaryBotanicalSubject}
                </h3>
                <p className="font-serif italic text-base text-[#55624b] mt-0.5">
                  {album.latinBinomial}
                </p>
              </div>

              {/* Collector Field Details */}
              <div className="space-y-2.5 text-xs text-[#81776D] font-sans border-y border-[#443C35]/10 py-3.5">
                <div className="flex items-start gap-2.5">
                  <MapPin size={14} className="text-[#89977D] shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] uppercase block text-[#81776D]/80">Station Coordinates</span>
                    <span className="text-[#443C35] font-serif">{album.herbariumLocation}</span>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <User size={14} className="text-[#89977D] shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] uppercase block text-[#81776D]/80">Primary Collector</span>
                    <span className="text-[#443C35] font-serif">{album.collector}</span>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <Calendar size={14} className="text-[#89977D] shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] uppercase block text-[#81776D]/80">Archival Year</span>
                    <span className="text-[#443C35] font-serif">Preserved Anno {album.yearPreserved}</span>
                  </div>
                </div>
              </div>

              {/* Linnaean Stamp */}
              <div className="p-3 rounded-md bg-[#EAE1D2]/70 text-[11px] text-[#443C35] font-serif italic border border-[#443C35]/10">
                "{album.curatorStamp}"
              </div>
            </div>
          </div>

          {/* Description & Acoustic Pairing */}
          <div className="space-y-3 pt-2">
            <h4 className="font-serif text-sm font-semibold uppercase tracking-wider text-[#81776D]">
              Historical & Acoustic Description
            </h4>
            <p className="text-xs text-[#443C35]/85 font-sans leading-relaxed">
              {album.description}
            </p>
          </div>

          {/* Associated Movements List */}
          <div className="space-y-2 pt-2">
            <h4 className="font-serif text-sm font-semibold uppercase tracking-wider text-[#81776D]">
              Scored Movements in this Folio ({album.tracks.length})
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {album.tracks.map((t) => (
                <div 
                  key={t.id}
                  className="p-2.5 rounded bg-[#F5F0E6] border border-[#443C35]/10 flex items-center justify-between text-xs"
                >
                  <div className="truncate pr-2">
                    <span className="font-mono text-[10px] text-[#81776D] mr-1.5">{t.movementNumber}</span>
                    <span className="font-serif font-medium text-[#443C35]">{t.title}</span>
                  </div>
                  <span className="text-[10px] font-serif italic text-[#55624b] shrink-0">
                    {t.key}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-[#443C35]/12 bg-[#F5F0E6] flex items-center justify-between">
          <span className="font-serif italic text-xs text-[#81776D]">
            Botanical Journal Audio • Folio Archive
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 rounded text-xs text-[#81776D] hover:text-[#443C35] cursor-pointer"
            >
              Return to Journal
            </button>
            <button
              onClick={() => {
                onPlayAlbum(album);
                onClose();
              }}
              className="px-4 py-1.5 rounded text-xs font-medium text-[#FBF8F1] bg-[#485B4C] hover:bg-[#3D4D40] transition-colors cursor-pointer shadow-xs flex items-center gap-1.5"
            >
              <Sparkles size={13} />
              <span>Listen to this Folio</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
