import React, { useState } from 'react';
import { 
  Feather, 
  Trash2, 
  Plus, 
  Sparkles, 
  BookOpen, 
  Download,
  Calendar
} from 'lucide-react';
import { MarginaliaEntry, Album } from '../types';

interface MarginaliaJournalViewProps {
  entries: MarginaliaEntry[];
  albums: Album[];
  onAddEntry: (trackId: string, content: string, seal: 'fern' | 'ginkgo' | 'rose' | 'lavender' | 'wax') => void;
  onDeleteEntry: (id: string) => void;
}

export const MarginaliaJournalView: React.FC<MarginaliaJournalViewProps> = ({
  entries,
  albums,
  onAddEntry,
  onDeleteEntry,
}) => {
  const [selectedTrackId, setSelectedTrackId] = useState<string>(
    albums[0]?.tracks[0]?.id || ''
  );
  const [content, setContent] = useState('');
  const [selectedSeal, setSelectedSeal] = useState<'fern' | 'ginkgo' | 'rose' | 'lavender' | 'wax'>('fern');
  const [filterSeal, setFilterSeal] = useState<string>('all');

  // Gather all tracks across albums
  const allTracks = albums.flatMap((a) =>
    a.tracks.map((t) => ({ ...t, albumTitle: a.title, catalog: a.catalogNumber }))
  );

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() || !selectedTrackId) return;
    onAddEntry(selectedTrackId, content.trim(), selectedSeal);
    setContent('');
  };

  const getSealGlyph = (type: string) => {
    switch (type) {
      case 'fern':
        return '🌿';
      case 'ginkgo':
        return '🍂';
      case 'rose':
        return '🌹';
      case 'lavender':
        return '🪻';
      case 'wax':
        return '𐚚';
      default:
        return '𐚚';
    }
  };

  const getSealBadgeStyle = (type: string) => {
    switch (type) {
      case 'fern':
        return 'bg-[#89977D]/20 text-[#55624b] border-[#89977D]/30';
      case 'ginkgo':
        return 'bg-[#C5A46D]/20 text-[#7a5654] border-[#C5A46D]/30';
      case 'rose':
        return 'bg-[#C99D9A]/25 text-[#795553] border-[#C99D9A]/40';
      case 'lavender':
        return 'bg-[#B7A8C8]/25 text-[#443C35] border-[#B7A8C8]/40';
      case 'wax':
        return 'bg-[#B97862]/20 text-[#B97862] border-[#B97862]/40';
      default:
        return 'bg-[#EAE1D2] text-[#443C35] border-[#443C35]/15';
    }
  };

  const filteredEntries = filterSeal === 'all' 
    ? entries 
    : entries.filter((entry) => entry.sealType === filterSeal);

  const exportNotesAsText = () => {
    const textData = entries
      .map(
        (e) =>
          `[${e.timestamp}] [Seal: ${e.sealType.toUpperCase()}] Movement: ${e.trackTitle}\n"${e.content}"\n`
      )
      .join('\n---\n\n');
    const blob = new Blob([textData], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `botanical-journal-marginalia-${new Date().toISOString().slice(0, 10)}.txt`;
    link.click();
  };

  return (
    <div className="w-full max-w-[1200px] mx-auto py-8 px-6 lg:px-10 animate-fade-in space-y-8">
      {/* Header */}
      <div className="border-b border-[#443C35]/15 pb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <span className="text-xs font-mono uppercase tracking-widest text-[#89977D]">
            Personal Listening Log • Handwritten Marginalia
          </span>
          <h2 className="font-serif text-3xl font-medium text-[#443C35] mt-1 tracking-tight">
            Listener Marginalia & Seals
          </h2>
          <p className="text-xs text-[#81776D] font-serif italic mt-1 max-w-xl">
            Inscribe personal acoustic reflections into the margins of your botanical compendium. Affix pressed specimens and wax seals to mark memorable passages.
          </p>
        </div>

        <button
          onClick={exportNotesAsText}
          disabled={entries.length === 0}
          className="px-3.5 py-1.5 rounded-md text-xs text-[#443C35] bg-[#EAE1D2] hover:bg-[#89977D]/25 border border-[#443C35]/10 flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
        >
          <Download size={13} />
          <span>Export Folio Notes</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Penning Form - 5 cols */}
        <div className="lg:col-span-5 space-y-6">
          <div className="paper-sheet p-6 rounded-lg space-y-4">
            <div className="flex items-center gap-2 text-sm font-medium text-[#443C35] border-b border-[#443C35]/10 pb-3">
              <Feather size={16} className="text-[#55624b]" />
              <span className="font-serif text-base">Inscribe New Marginalia</span>
            </div>

            <form onSubmit={handleAdd} className="space-y-4">
              {/* Movement Selector */}
              <div>
                <label className="text-[11px] uppercase tracking-wider font-mono text-[#81776D] block mb-1">
                  Target Movement / Specimen
                </label>
                <select
                  value={selectedTrackId}
                  onChange={(e) => setSelectedTrackId(e.target.value)}
                  className="w-full text-xs text-[#443C35] bg-[#F5F0E6] p-2 rounded border border-[#443C35]/15 font-serif focus:border-[#B97862] outline-none"
                >
                  {allTracks.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.catalog} • {t.movementNumber} - {t.title} ({t.specimenName})
                    </option>
                  ))}
                </select>
              </div>

              {/* Ruled Ledger Textarea */}
              <div>
                <label className="text-[11px] uppercase tracking-wider font-mono text-[#81776D] block mb-1">
                  Acoustic & Botanical Reflection
                </label>
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Describe the timbre of strings, damp moss aromas, or the daylight filtering through the panes..."
                  rows={4}
                  className="w-full text-xs text-[#443C35] ledger-input placeholder:text-[#81776D]/60 placeholder:font-serif resize-none p-1.5"
                />
              </div>

              {/* Seal Selector */}
              <div>
                <label className="text-[11px] uppercase tracking-wider font-mono text-[#81776D] block mb-2">
                  Affix Pressed Specimen Seal
                </label>
                <div className="grid grid-cols-5 gap-2">
                  {(['fern', 'ginkgo', 'rose', 'lavender', 'wax'] as const).map((seal) => (
                    <button
                      type="button"
                      key={seal}
                      onClick={() => setSelectedSeal(seal)}
                      className={`p-2 rounded-lg text-center flex flex-col items-center gap-1 transition-all cursor-pointer ${
                        selectedSeal === seal
                          ? 'bg-[#B97862]/20 border border-[#B97862] text-[#443C35] shadow-2xs'
                          : 'bg-[#F5F0E6] border border-[#443C35]/10 hover:border-[#443C35]/25 text-[#81776D]'
                      }`}
                    >
                      <span className="text-base leading-none">{getSealGlyph(seal)}</span>
                      <span className="text-[10px] capitalize font-serif">{seal}</span>
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                disabled={!content.trim()}
                className="w-full py-2.5 rounded-lg text-xs font-medium text-[#FBF8F1] transition-transform active:scale-98 disabled:opacity-40 flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                style={{ backgroundColor: '#485B4C' }}
              >
                <Plus size={14} />
                <span>Affix Marginalia to Journal</span>
              </button>
            </form>
          </div>
        </div>

        {/* Right Column: Historical Entries Spread - 7 cols */}
        <div className="lg:col-span-7 space-y-5">
          {/* Filter Chips by Seal */}
          <div className="flex items-center justify-between gap-3 pb-1">
            <span className="text-xs font-serif italic text-[#81776D]">
              {filteredEntries.length} Inscribed Folio {filteredEntries.length === 1 ? 'Note' : 'Notes'}
            </span>

            <div className="flex items-center gap-1.5 text-xs">
              {['all', 'fern', 'ginkgo', 'rose', 'lavender', 'wax'].map((s) => (
                <button
                  key={s}
                  onClick={() => setFilterSeal(s)}
                  className={`px-2.5 py-1 rounded-full text-[11px] capitalize transition-colors cursor-pointer ${
                    filterSeal === s
                      ? 'bg-[#B97862] text-[#FBF8F1] font-medium shadow-2xs'
                      : 'bg-[#EAE1D2] text-[#81776D] hover:text-[#443C35]'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {filteredEntries.length === 0 ? (
            <div className="paper-sheet p-10 text-center rounded-lg space-y-2">
              <BookOpen size={28} className="mx-auto text-[#81776D]/50" />
              <h4 className="font-serif text-base text-[#443C35]">No Marginalia Inscribed Yet</h4>
              <p className="text-xs text-[#81776D] font-serif italic">
                Use the pen desk on the left to record your initial thoughts on any movement.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredEntries.map((entry) => (
                <div
                  key={entry.id}
                  className="paper-sheet rounded-lg p-5 relative group transition-all hover:shadow-sm"
                >
                  <div className="flex items-start justify-between gap-4 mb-2">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded-full text-xs border flex items-center gap-1 font-serif ${getSealBadgeStyle(entry.sealType)}`}>
                        <span>{getSealGlyph(entry.sealType)}</span>
                        <span className="capitalize">{entry.sealType} Seal</span>
                      </span>

                      <h4 className="font-serif text-sm font-medium text-[#443C35]">
                        {entry.trackTitle}
                      </h4>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-[11px] text-[#81776D] font-mono flex items-center gap-1">
                        <Calendar size={11} />
                        {entry.timestamp}
                      </span>
                      <button
                        onClick={() => onDeleteEntry(entry.id)}
                        className="p-1 text-[#81776D] hover:text-[#ba1a1a] transition-colors cursor-pointer opacity-0 group-hover:opacity-100"
                        title="Erase Note"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>

                  <p 
                    className="font-serif text-sm leading-relaxed pl-1 italic"
                    style={{ color: entry.pencilShade || '#443C35' }}
                  >
                    "{entry.content}"
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
