import React from 'react';
import { Play, Sparkles, Disc, Feather, ArrowRight } from 'lucide-react';
import { Album } from '../types';

interface HerbariumLibraryViewProps {
  albums: Album[];
  selectedShelf: string;
  selectedTag: string;
  searchQuery: string;
  onSelectAlbum: (album: Album) => void;
  onPlayAlbum: (album: Album) => void;
  onInspectSpecimen: (album: Album) => void;
}

export const HerbariumLibraryView: React.FC<HerbariumLibraryViewProps> = ({
  albums,
  selectedShelf,
  selectedTag,
  searchQuery,
  onSelectAlbum,
  onPlayAlbum,
  onInspectSpecimen,
}) => {
  // Filter albums according to shelf, tag, and query
  const filteredAlbums = albums.filter((album) => {
    const matchesShelf = selectedShelf === 'all' || album.shelf === selectedShelf;
    const matchesTag =
      !selectedTag ||
      album.tracks.some((t) => t.tags.includes(selectedTag) || t.instrumentation.includes(selectedTag));
    const q = searchQuery.toLowerCase().trim();
    const matchesQuery =
      !q ||
      album.title.toLowerCase().includes(q) ||
      album.latinBinomial.toLowerCase().includes(q) ||
      album.primaryBotanicalSubject.toLowerCase().includes(q) ||
      album.catalogNumber.toLowerCase().includes(q) ||
      album.tracks.some((t) => t.title.toLowerCase().includes(q) || t.latinName.toLowerCase().includes(q));

    return matchesShelf && matchesTag && matchesQuery;
  });

  return (
    <div className="w-full max-w-[1200px] mx-auto py-8 px-6 lg:px-10 animate-fade-in space-y-8">
      {/* Herbarium Library Header */}
      <div className="border-b border-[#443C35]/15 pb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <span className="text-xs font-mono uppercase tracking-widest text-[#89977D]">
            Archival Repository • Folios I–V
          </span>
          <h2 className="font-serif text-3xl font-medium text-[#443C35] mt-1 tracking-tight">
            The Herbarium & Shelves
          </h2>
          <p className="text-xs text-[#81776D] font-serif italic mt-1 max-w-xl">
            Pressed botanical specimens bound with field recordings and chamber movements. Each folio preserves flora in gum arabic and unhurried acoustic sound.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-xs font-mono text-[#81776D] px-3 py-1 rounded-full bg-[#EAE1D2] border border-[#443C35]/10">
            {filteredAlbums.length} Compendiums Cataloged
          </span>
        </div>
      </div>

      {/* Grid of Albums with Archival Art Print Mats (6px ivory border) */}
      {filteredAlbums.length === 0 ? (
        <div className="paper-sheet p-12 text-center rounded-lg space-y-3">
          <Disc size={32} className="mx-auto text-[#81776D]/60" />
          <h3 className="font-serif text-lg text-[#443C35]">No Botanical Folios Match Your Criteria</h3>
          <p className="text-xs text-[#81776D] font-serif italic max-w-md mx-auto">
            Try choosing another botanical shelf, resetting the parchment tags, or clearing the search query.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
          {filteredAlbums.map((album) => {
            return (
              <div 
                key={album.id}
                className="paper-sheet rounded-lg p-5 flex flex-col justify-between group transition-all duration-300 hover:shadow-md hover:-translate-y-0.5"
              >
                <div>
                  {/* Gatefold Art Print with 6px Ivory Mat */}
                  <div 
                    onClick={() => onSelectAlbum(album)}
                    className="relative aspect-square w-full rounded-sm overflow-hidden cursor-pointer"
                    style={{
                      boxShadow: '0 0 0 6px #F5F0E6, 0 6px 18px rgba(68, 60, 53, 0.12)'
                    }}
                  >
                    <img 
                      src={album.coverUrl} 
                      alt={album.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-104"
                    />
                    <div className="absolute inset-0 bg-[#443C35]/0 group-hover:bg-[#443C35]/15 transition-colors" />

                    {/* Catalog badge */}
                    <div className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded bg-[#FBF8F1]/90 text-[10px] font-mono text-[#443C35] border border-[#443C35]/10 backdrop-blur-xs">
                      {album.catalogNumber}
                    </div>

                    {/* Quick play overlay on hover */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onPlayAlbum(album);
                      }}
                      className="absolute bottom-3 right-3 w-10 h-10 rounded-full flex items-center justify-center transition-transform active:scale-90 opacity-0 group-hover:opacity-100 duration-200 cursor-pointer shadow-md"
                      style={{ backgroundColor: '#485B4C', color: '#FBF8F1' }}
                      title={`Play ${album.title}`}
                    >
                      <Play size={16} className="fill-[#FBF8F1] ml-0.5" />
                    </button>
                  </div>

                  {/* Album & Specimen Meta */}
                  <div className="mt-5 space-y-2">
                    <div className="flex items-center justify-between text-[11px] text-[#81776D] font-mono">
                      <span>{album.collection}</span>
                      <span>{album.releaseEra}</span>
                    </div>

                    <h3 
                      onClick={() => onSelectAlbum(album)}
                      className="font-serif text-xl font-medium text-[#443C35] leading-tight group-hover:text-[#55624b] transition-colors cursor-pointer"
                    >
                      {album.title}
                    </h3>

                    <div className="flex items-center gap-2 text-xs text-[#55624b] font-serif italic">
                      <Sparkles size={11} />
                      <span>{album.latinBinomial}</span>
                    </div>

                    <p className="text-xs text-[#443C35]/75 line-clamp-2 font-sans pt-1 leading-relaxed">
                      {album.description}
                    </p>
                  </div>
                </div>

                {/* Footer Controls */}
                <div className="mt-5 pt-3 border-t border-[#443C35]/10 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 text-[11px] text-[#81776D]">
                    <Feather size={12} className="text-[#89977D]" />
                    <span>{album.tracks.length} Movements</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onInspectSpecimen(album)}
                      className="p-1.5 text-[#81776D] hover:text-[#55624b] transition-colors cursor-pointer"
                      title="Inspect Specimen Plate"
                    >
                      <Sparkles size={14} />
                    </button>
                    <button
                      onClick={() => onSelectAlbum(album)}
                      className="flex items-center gap-1 px-2.5 py-1 rounded text-[11px] text-[#443C35] bg-[#EAE1D2] hover:bg-[#89977D]/25 transition-colors cursor-pointer font-medium"
                    >
                      <span>Open Folio</span>
                      <ArrowRight size={11} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
