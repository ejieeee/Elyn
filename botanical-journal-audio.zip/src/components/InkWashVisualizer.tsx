import React, { useEffect, useRef } from 'react';
import { soundEngine } from '../services/soundEngine';

interface InkWashVisualizerProps {
  isPlaying: boolean;
  accentColor?: string; // e.g. '#89977D' or '#B97862'
  height?: number;
}

export const InkWashVisualizer: React.FC<InkWashVisualizerProps> = ({
  isPlaying,
  accentColor = '#89977D',
  height = 54,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let phase = 0;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const width = canvas.width;
      const h = canvas.height;

      // Get real audio frequency data or simulate gentle paper ripple
      const freqData = soundEngine.getAnalyserData();
      const timeData = soundEngine.getTimeDomainData();

      const pointsCount = 48;
      const step = width / (pointsCount - 1);
      const centerY = h * 0.65;

      // Draw faint watercolor bloom background
      const grad = ctx.createLinearGradient(0, 0, width, 0);
      grad.addColorStop(0, 'rgba(137, 151, 125, 0.08)');
      grad.addColorStop(0.5, 'rgba(182, 201, 210, 0.15)');
      grad.addColorStop(1, 'rgba(185, 120, 98, 0.08)');

      ctx.beginPath();
      ctx.moveTo(0, centerY);

      for (let i = 0; i < pointsCount; i++) {
        const x = i * step;
        let amplitude = 0;

        if (isPlaying && freqData && timeData) {
          const rawVal = freqData[i % freqData.length] / 255;
          const timeVal = (timeData[i % timeData.length] - 128) / 128;
          amplitude = (rawVal * 0.7 + timeVal * 0.3) * (h * 0.45);
        } else {
          // Gentle resting water ripple
          amplitude = Math.sin(phase + i * 0.3) * 3;
        }

        const y = centerY - amplitude;
        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          const prevX = (i - 1) * step;
          const cpX = (prevX + x) / 2;
          ctx.quadraticCurveTo(cpX, y, x, y);
        }
      }

      ctx.lineTo(width, h);
      ctx.lineTo(0, h);
      ctx.closePath();
      ctx.fillStyle = grad;
      ctx.fill();

      // Soft pencil / sumi-ink contour rule
      ctx.beginPath();
      for (let i = 0; i < pointsCount; i++) {
        const x = i * step;
        let amplitude = 0;

        if (isPlaying && freqData && timeData) {
          const rawVal = freqData[i % freqData.length] / 255;
          const timeVal = (timeData[i % timeData.length] - 128) / 128;
          amplitude = (rawVal * 0.7 + timeVal * 0.3) * (h * 0.45);
        } else {
          amplitude = Math.sin(phase + i * 0.3) * 3;
        }

        const y = centerY - amplitude;
        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          const prevX = (i - 1) * step;
          const cpX = (prevX + x) / 2;
          ctx.quadraticCurveTo(cpX, y, x, y);
        }
      }

      ctx.strokeStyle = isPlaying ? accentColor : 'rgba(68, 60, 53, 0.22)';
      ctx.lineWidth = isPlaying ? 1.5 : 1;
      ctx.stroke();

      // Subtle ink beads / droplet spatter points
      if (isPlaying) {
        for (let j = 4; j < pointsCount; j += 7) {
          const x = j * step;
          const val = freqData ? freqData[j % freqData.length] / 255 : 0;
          if (val > 0.35) {
            ctx.beginPath();
            ctx.arc(x, centerY - val * 24 - 4, 1.8, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(185, 120, 98, 0.65)';
            ctx.fill();
          }
        }
      }

      phase += 0.03;
      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [isPlaying, accentColor]);

  return (
    <div className="w-full relative overflow-hidden rounded-md" style={{ height }}>
      <canvas
        ref={canvasRef}
        width={600}
        height={height}
        className="w-full h-full block"
      />
      <div className="absolute right-2 top-1 font-serif italic text-[10px] text-[#81776D]/60 select-none pointer-events-none">
        {isPlaying ? 'Acoustic Resonance: Active' : 'Sumi-ink Waveform: Quiescent'}
      </div>
    </div>
  );
};
