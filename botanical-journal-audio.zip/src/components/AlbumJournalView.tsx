import React, { useState } from 'react';
import { 
  Play, 
  Pause, 
  Bookmark, 
  Sparkles, 
  Clock, 
  Music, 
  Compass, 
  Feather,
  Plus,
  Check
} from 'lucide-react';
import { Album, Track } from '../types';
import { InkWashVisualizer } from './InkWashVisualizer';

interface AlbumJournalViewProps {
  album: Album;
  currentTrack: Track | null;
  isPlaying: boolean;
  onPlayTrack: (track: Track) => void;
  onToggleFavorite: (trackId: string) => void;
  onOpenSpecimenModal: () => void;
  onAddMarginalia: (trackId: string, content: string, seal: 'fern' | 'ginkgo' | 'rose' | 'lavender' | 'wax') => void;
}

export const AlbumJournalView: React.FC<AlbumJournalViewProps> = ({
  album,
  currentTrack,
  isPlaying,
  onPlayTrack,
  onToggleFavorite,
  onOpenSpecimenModal,
  onAddMarginalia,
}) => {
  const [showNoteInputForTrack, setShowNoteInputForTrack] = useState<string | null>(null);
  const [noteContent, setNoteContent] = useState('');
  const [selectedSeal, setSelectedSeal] = useState<'fern' | 'ginkgo' | 'rose' | 'lavender' | 'wax'>('fern');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const formatDuration = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rem = Math.floor(secs % 60);
    return `${mins}:${rem < 10 ? '0' : ''}${rem}`;
  };

  const totalAlbumDuration = album.tracks.reduce((acc, t) => acc + t.duration, 0);

  const handleSaveNote = (trackId: string) => {
    if (!noteContent.trim()) return;
    onAddMarginalia(trackId, noteContent.trim(), selectedSeal);
    setNoteContent('');
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      setShowNoteInputForTrack(null);
    }, 1200);
  };

  return (
    <div className="w-full max-w-[1200px] mx-auto py-8 px-6 lg:px-10 animate-fade-in">
      {/* Top Folio Breadcrumb & Archival Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-6 border-b border-[#443C35]/15 mb-8">
        <div className="flex items-center gap-2 text-xs font-mono tracking-wider text-[#81776D] uppercase">
          <span>{album.shelf}</span>
          <span>/</span>
          <span className="text-[#55624b] font-medium">{album.collection}</span>
          <span>/</span>
          <span>{album.catalogNumber}</span>
        </div>

        <div className="flex items-center gap-3">
          <div className="font-serif italic text-xs text-[#81776D]">
            Preserved Anno {album.yearPreserved}
          </div>
          <button
            onClick={onOpenSpecimenModal}
            className="px-3 py-1 text-xs rounded-full bg-[#EAE1D2] hover:bg-[#A5B49A]/30 text-[#443C35] border border-[#443C35]/15 transition-all cursor-pointer flex items-center gap-1.5 shadow-2xs"
          >
            <Sparkles size={12} className="text-[#55624b]" />
            <span>Examine Specimen Plate</span>
          </button>
        </div>
      </div>

      {/* Asymmetric Dual-Page Book Spread Architecture */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Page (The Specimen Bookplate & Archival Details) - 5 cols */}
        <div className="lg:col-span-5 space-y-6">
          {/* Archival Art Print Mat (6px Ivory Border Mat) */}
          <div className="paper-sheet p-5 rounded-lg relative overflow-hidden">
            {/* Tipped-in Bookplate Album Cover */}
            <div 
              className="relative aspect-square w-full rounded-sm overflow-hidden cursor-pointer group"
              style={{
                boxShadow: '0 0 0 6px #F5F0E6, 0 10px 24px -2px rgba(68, 60, 53, 0.16)'
              }}
              onClick={onOpenSpecimenModal}
            >
              <img 
                src={album.coverUrl} 
                alt={album.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-103"
              />
              <div className="absolute inset-0 bg-radial from-transparent to-[#443C35]/20 opacity-60" />
              
              {/* Embossed Corner Archival Stamp */}
              <div className="absolute bottom-2.5 right-2.5 px-2.5 py-1 rounded bg-[#FBF8F1]/95 text-[10px] font-mono text-[#443C35] border border-[#443C35]/15 backdrop-blur-xs flex items-center gap-1.5 shadow-xs">
                <span>{album.catalogNumber}</span>
              </div>
            </div>

            {/* Specimen Field Label (Simulated antique collector tag) */}
            <div className="mt-6 pt-5 border-t border-[#443C35]/10 space-y-3">
              <div>
                <span className="text-[10px] uppercase font-mono tracking-widest text-[#81776D]">
                  Primary Botanical Specimen
                </span>
                <h3 className="font-serif text-xl font-medium text-[#443C35] mt-0.5">
                  {album.primaryBotanicalSubject}
                </h3>
                <p className="font-serif italic text-sm text-[#55624b]">
                  {album.latinBinomial}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs pt-1 text-[#81776D] font-sans">
                <div>
                  <span className="text-[10px] uppercase block text-[#81776D]/75">Collection Site</span>
                  <span className="text-[#443C35] font-serif">{album.herbariumLocation}</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase block text-[#81776D]/75">Collector</span>
                  <span className="text-[#443C35] font-serif">{album.collector}</span>
                </div>
              </div>

              <p className="text-xs text-[#443C35]/80 leading-relaxed font-sans pt-1 border-t border-[#443C35]/08">
                {album.description}
              </p>

              {/* Curator Seal Stamp */}
              <div className="pt-2 flex items-center justify-between text-[10px] text-[#81776D]">
                <span className="font-serif italic text-[#81776D]/90">
                  {album.curatorStamp}
                </span>
                <span className="font-mono text-[#55624b]">
                  {album.tracks.length} Movements • {formatDuration(totalAlbumDuration)}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Play Master Action */}
          <div className="paper-sheet p-4 rounded-lg flex items-center justify-between gap-4">
            <div>
              <span className="text-xs text-[#81776D] block font-serif">Commence Full Folio</span>
              <span className="text-sm font-medium text-[#443C35]">
                {isPlaying && currentTrack?.albumId === album.id ? 'Playing Folio Now' : 'Sequential Listening'}
              </span>
            </div>

            <button
              onClick={() => {
                if (album.tracks.length > 0) {
                  onPlayTrack(album.tracks[0]);
                }
              }}
              className="px-4 py-2 rounded-lg text-xs font-medium text-[#FBF8F1] flex items-center gap-2 transition-transform active:scale-95 cursor-pointer shadow-sm"
              style={{ backgroundColor: '#485B4C' }}
            >
              <Play size={13} className="fill-[#FBF8F1]" />
              <span>Begin at Mov. I</span>
            </button>
          </div>
        </div>

        {/* Right Page (The Movement Score & Tracklist) - 7 cols */}
        <div className="lg:col-span-7 space-y-6">
          {/* Folio Title Banner */}
          <div className="paper-sheet p-6 rounded-lg">
            <span className="text-xs font-mono text-[#89977D] tracking-widest uppercase">
              {album.subtitle}
            </span>
            <h2 className="font-serif text-3xl font-medium text-[#443C35] mt-1 mb-2 tracking-tight">
              {album.title}
            </h2>
            <div className="flex flex-wrap items-center gap-4 text-xs text-[#81776D] pt-1 border-t border-[#443C35]/10">
              <span className="flex items-center gap-1.5">
                <Clock size={13} />
                <span>{album.releaseEra}</span>
              </span>
              <span>•</span>
              <span className="flex items-center gap-1.5">
                <Music size={13} />
                <span>{album.tracks.length} Recorded Movements</span>
              </span>
              <span>•</span>
              <span className="flex items-center gap-1.5">
                <Compass size={13} />
                <span>Acoustic Chamber Calibration</span>
              </span>
            </div>

            {/* Embedded Watercolor Ink-Wash Waveform Visualizer */}
            <div className="mt-5 pt-4 border-t border-[#443C35]/10">
              <InkWashVisualizer isPlaying={isPlaying && currentTrack?.albumId === album.id} />
            </div>
          </div>

          {/* Movements Tracklist: strictly NO alternating zebra stripes, gossamer dividers */}
          <div className="paper-sheet rounded-lg overflow-hidden">
            <div className="px-5 py-3 border-b border-[#443C35]/10 bg-[#FBF8F1] flex items-center justify-between text-xs text-[#81776D]">
              <span className="font-serif italic">Movements & Specimens</span>
              <span className="font-mono text-[11px]">Duration</span>
            </div>

            <div className="divide-y divide-[#81776D]/15">
              {album.tracks.map((track, idx) => {
                const isThisTrackActive = currentTrack?.id === track.id;
                const isThisPlaying = isThisTrackActive && isPlaying;
                const isWritingNote = showNoteInputForTrack === track.id;

                return (
                  <div 
                    key={track.id}
                    className={`transition-colors duration-150 ${
                      isThisTrackActive 
                        ? 'bg-[#89977D]/12 border-l-3 border-[#55624b]' 
                        : 'bg-[#FBF8F1] hover:bg-[#F5F0E6]/60'
                    }`}
                  >
                    <div className="p-4 flex items-start justify-between gap-3">
                      {/* Left: Index / Botanical glyph & Play trigger */}
                      <div className="flex items-start gap-3.5 flex-1 min-w-0">
                        <button
                          onClick={() => onPlayTrack(track)}
                          className={`mt-0.5 w-7 h-7 rounded-full flex items-center justify-center shrink-0 transition-transform active:scale-95 cursor-pointer ${
                            isThisPlaying
                              ? 'bg-[#485B4C] text-[#FBF8F1] shadow-xs'
                              : 'bg-[#EAE1D2] text-[#443C35] hover:bg-[#89977D]/25'
                          }`}
                          title={isThisPlaying ? 'Pause Movement' : `Play ${track.title}`}
                        >
                          {isThisPlaying ? (
                            <Pause size={12} className="fill-[#FBF8F1]" />
                          ) : (
                            <Play size={12} className="fill-current ml-0.5" />
                          )}
                        </button>

                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <span className="text-[11px] font-mono text-[#81776D]">
                              {track.movementNumber}
                            </span>
                            {/* Botanical ink dot or glyph for active track */}
                            {isThisTrackActive && (
                              <span className="inline-block w-2 h-2 rounded-full bg-[#B97862] animate-pulse" />
                            )}
                            <h4 className="font-serif text-base font-medium text-[#443C35] truncate leading-tight">
                              {track.title}
                            </h4>
                          </div>

                          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1 text-xs text-[#81776D]">
                            <span className="font-serif italic text-[#55624b]">
                              {track.latinName}
                            </span>
                            <span>•</span>
                            <span className="font-mono text-[10px] text-[#81776D]/80">
                              Key of {track.key}
                            </span>
                            <span>•</span>
                            <span className="text-[10px] text-[#81776D]">
                              {track.bpm} BPM
                            </span>
                          </div>

                          {/* Curatorial marginalia note */}
                          <p className="mt-1.5 text-xs text-[#443C35]/75 font-serif italic leading-relaxed pr-2">
                            "{track.curatorNotes}"
                          </p>

                          {/* Instrumentation chips: Antique Paper inactive pill contour */}
                          <div className="flex flex-wrap gap-1.5 mt-2">
                            {track.instrumentation.map((inst) => (
                              <span 
                                key={inst}
                                className="px-2 py-0.5 rounded-full text-[10px] bg-[#EAE1D2] text-[#81776D] font-sans"
                              >
                                {inst}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Right: Actions & Duration */}
                      <div className="flex items-center gap-2 shrink-0 pt-0.5">
                        <button
                          onClick={() => {
                            setShowNoteInputForTrack(isWritingNote ? null : track.id);
                          }}
                          className={`p-1.5 rounded-full transition-colors cursor-pointer text-[#81776D] hover:text-[#443C35] ${
                            isWritingNote ? 'bg-[#C99D9A]/30 text-[#443C35]' : 'hover:bg-[#EAE1D2]'
                          }`}
                          title="Pen Marginalia for this Movement"
                        >
                          <Feather size={14} />
                        </button>

                        <button
                          onClick={() => onToggleFavorite(track.id)}
                          className="p-1.5 rounded-full text-[#81776D] hover:text-[#B97862] transition-colors cursor-pointer"
                          title="Save Bookmark"
                        >
                          <Bookmark 
                            size={14} 
                            className={track.isFavorite ? 'fill-[#B97862] text-[#B97862]' : ''} 
                          />
                        </button>

                        <span className="font-mono text-xs text-[#81776D] min-w-[36px] text-right">
                          {formatDuration(track.duration)}
                        </span>
                      </div>
                    </div>

                    {/* Inline Marginalia Penning Desk */}
                    {isWritingNote && (
                      <div className="px-5 py-4 bg-[#F5F0E6] border-t border-[#443C35]/10 animate-fade-in space-y-3">
                        <div className="flex items-center justify-between text-xs text-[#81776D]">
                          <span className="font-serif italic flex items-center gap-1.5">
                            <Feather size={13} className="text-[#55624b]" />
                            Pen Field Marginalia for "{track.title}"
                          </span>
                          <span className="text-[10px] font-mono uppercase tracking-wider">
                            Personal Archival Log
                          </span>
                        </div>

                        {/* Ruled ledger style input */}
                        <textarea
                          value={noteContent}
                          onChange={(e) => setNoteContent(e.target.value)}
                          placeholder="Note acoustic observations, resonance impressions, or botanical associations..."
                          rows={2}
                          className="w-full text-xs text-[#443C35] ledger-input placeholder:text-[#81776D]/60 placeholder:font-serif resize-none p-1"
                        />

                        {/* Wax Seal / Stamp Selector */}
                        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                          <div className="flex items-center gap-1.5 text-xs text-[#81776D]">
                            <span className="text-[11px] font-serif">Specimen Seal:</span>
                            {(['fern', 'ginkgo', 'rose', 'lavender', 'wax'] as const).map((seal) => (
                              <button
                                key={seal}
                                onClick={() => setSelectedSeal(seal)}
                                className={`px-2 py-0.5 rounded-full text-[10px] capitalize transition-all cursor-pointer ${
                                  selectedSeal === seal
                                    ? 'bg-[#B97862] text-[#FBF8F1] shadow-2xs'
                                    : 'bg-[#EAE1D2] text-[#443C35] hover:bg-[#89977D]/20'
                                }`}
                              >
                                {seal}
                              </button>
                            ))}
                          </div>

                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => setShowNoteInputForTrack(null)}
                              className="px-2.5 py-1 text-xs text-[#81776D] hover:text-[#443C35] cursor-pointer"
                            >
                              Dismiss
                            </button>
                            <button
                              onClick={() => handleSaveNote(track.id)}
                              disabled={!noteContent.trim() || savedSuccess}
                              className="px-3 py-1 rounded text-xs text-[#FBF8F1] bg-[#485B4C] hover:bg-[#3D4D40] transition-colors disabled:opacity-40 flex items-center gap-1.5 cursor-pointer shadow-xs"
                            >
                              {savedSuccess ? (
                                <>
                                  <Check size={12} />
                                  <span>Affixed</span>
                                </>
                              ) : (
                                <>
                                  <Plus size={12} />
                                  <span>Affix to Journal</span>
                                </>
                              )}
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
