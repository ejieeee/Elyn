import React, { useState } from 'react';
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Shuffle, 
  Repeat, 
  Volume2, 
  VolumeX, 
  Bookmark,
  Maximize2,
  Sparkles
} from 'lucide-react';
import { Track, Album } from '../types';

interface TheEaselProps {
  currentTrack: Track | null;
  currentAlbum: Album | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  onPlayPause: () => void;
  onSeek: (seconds: number) => void;
  onVolumeChange: (val: number) => void;
  onNextTrack: () => void;
  onPrevTrack: () => void;
  onToggleFavorite: (trackId: string) => void;
  onOpenSpecimenModal: () => void;
}

export const TheEasel: React.FC<TheEaselProps> = ({
  currentTrack,
  currentAlbum,
  isPlaying,
  currentTime,
  duration,
  volume,
  onPlayPause,
  onSeek,
  onVolumeChange,
  onNextTrack,
  onPrevTrack,
  onToggleFavorite,
  onOpenSpecimenModal,
}) => {
  const [isShuffle, setIsShuffle] = useState(false);
  const [isRepeat, setIsRepeat] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [previousVolume, setPreviousVolume] = useState(volume);
  const [isHoveringScrubber, setIsHoveringScrubber] = useState(false);
  const [hoverTime, setHoverTime] = useState<number | null>(null);
  const [hoverPositionX, setHoverPositionX] = useState<number>(0);

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainingSecs = Math.floor(secs % 60);
    return `${mins}:${remainingSecs < 10 ? '0' : ''}${remainingSecs}`;
  };

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  const handleScrubberMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const percent = Math.max(0, Math.min(1, clickX / rect.width));
    setHoverPositionX(clickX);
    setHoverTime(percent * duration);
  };

  const handleScrubberClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickPercent = Math.max(0, Math.min(1, clickX / rect.width));
    onSeek(clickPercent * duration);
  };

  const toggleMute = () => {
    if (isMuted) {
      setIsMuted(false);
      onVolumeChange(previousVolume || 0.8);
    } else {
      setPreviousVolume(volume);
      setIsMuted(true);
      onVolumeChange(0);
    }
  };

  return (
    <footer 
      className="h-[92px] w-full px-6 py-2.5 z-30 transition-all duration-300"
      style={{
        backgroundColor: '#FBF8F1',
        borderTop: '1px solid rgba(68, 60, 53, 0.12)',
        boxShadow: '0 -4px 20px -2px rgba(68, 60, 53, 0.06), 0 -1px 3px 0 rgba(68, 60, 53, 0.04)'
      }}
    >
      <div className="max-w-[1400px] h-full mx-auto flex flex-col justify-between">
        {/* Soft Pencil Rule Scrubber Bar */}
        <div 
          className="relative w-full pt-1 pb-1 cursor-pointer group flex items-center"
          onMouseEnter={() => setIsHoveringScrubber(true)}
          onMouseLeave={() => {
            setIsHoveringScrubber(false);
            setHoverTime(null);
          }}
          onMouseMove={handleScrubberMouseMove}
          onClick={handleScrubberClick}
        >
          {/* Hover timestamp tooltip */}
          {isHoveringScrubber && hoverTime !== null && (
            <div 
              className="absolute -top-6 px-1.5 py-0.5 rounded text-[10px] font-mono text-[#FBF8F1] pointer-events-none transform -translate-x-1/2 shadow-xs transition-opacity z-10"
              style={{
                left: `${hoverPositionX}px`,
                backgroundColor: '#443C35'
              }}
            >
              {formatTime(hoverTime)}
            </div>
          )}

          {/* Pencil Rule Background Track */}
          <div 
            className="w-full h-1 rounded-full relative overflow-visible"
            style={{ backgroundColor: 'rgba(68, 60, 53, 0.14)' }}
          >
            {/* Watercolor Wash Gradient Elapsed Fill */}
            <div 
              className="h-full rounded-l-full relative transition-all duration-150 ease-out"
              style={{ 
                width: `${progressPercent}%`,
                background: 'linear-gradient(90deg, #89977D 0%, #A5B49A 65%, #B6C9D2 100%)',
                boxShadow: isPlaying ? '0 0 8px rgba(137, 151, 125, 0.4)' : 'none'
              }}
            >
              {/* Feathery bleed indicator */}
              <div 
                className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 rounded-full blur-[2px] opacity-70 pointer-events-none"
                style={{ backgroundColor: '#B6C9D2' }}
              />
            </div>

            {/* Terracotta Thumb Handle Bead (14px) */}
            <div 
              className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-3.5 h-3.5 rounded-full transition-transform duration-100 ease-out pointer-events-none"
              style={{
                left: `${progressPercent}%`,
                backgroundColor: '#B97862',
                boxShadow: '0 2px 6px rgba(185, 120, 98, 0.45)',
                transform: `translate(-50%, -50%) scale(${isHoveringScrubber ? 1.25 : 1.0})`,
                border: '1.5px solid #FBF8F1'
              }}
            />
          </div>
        </div>

        {/* Lower Row Controls & Track Meta */}
        <div className="flex items-center justify-between gap-4 mt-0.5">
          {/* Left: Current Movement & Specimen Info */}
          <div className="flex items-center gap-3.5 min-w-[260px] max-w-[340px]">
            {currentAlbum && (
              <div 
                onClick={onOpenSpecimenModal}
                className="relative shrink-0 w-12 h-12 rounded-sm overflow-hidden cursor-pointer group"
                style={{
                  boxShadow: '0 0 0 3px #F5F0E6, 0 2px 8px rgba(68, 60, 53, 0.12)'
                }}
                title="Inspect Archival Specimen"
              >
                <img 
                  src={currentAlbum.coverUrl} 
                  alt={currentAlbum.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-[#443C35]/10 group-hover:bg-transparent transition-colors flex items-center justify-center">
                  <Maximize2 size={12} className="text-[#FBF8F1] opacity-0 group-hover:opacity-100 transition-opacity drop-shadow" />
                </div>
              </div>
            )}

            <div className="truncate">
              {currentTrack ? (
                <>
                  <div className="flex items-center gap-2">
                    <span className="font-serif italic text-xs text-[#81776D]">
                      {currentTrack.movementNumber}
                    </span>
                    <h3 className="font-serif font-medium text-sm text-[#443C35] truncate leading-tight">
                      {currentTrack.title}
                    </h3>
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-[#81776D] mt-0.5 truncate">
                    <span className="italic font-serif truncate text-[#55624b]">
                      {currentTrack.latinName}
                    </span>
                    <span>•</span>
                    <span className="font-mono text-[10px] text-[#81776D]/80">
                      {currentAlbum?.catalogNumber || 'FOLIO IV'}
                    </span>
                  </div>
                </>
              ) : (
                <div className="font-serif italic text-xs text-[#81776D]">
                  Select an archival folio to commence playback...
                </div>
              )}
            </div>

            {currentTrack && (
              <button
                onClick={() => onToggleFavorite(currentTrack.id)}
                className="p-1.5 rounded-full text-[#81776D] hover:text-[#B97862] transition-colors cursor-pointer shrink-0 ml-1"
                title={currentTrack.isFavorite ? 'In Archival Favorites' : 'Add to Pressed Favorites'}
              >
                <Bookmark 
                  size={15} 
                  className={currentTrack.isFavorite ? 'fill-[#B97862] text-[#B97862]' : ''} 
                />
              </button>
            )}
          </div>

          {/* Center: Playback Controls */}
          <div className="flex flex-col items-center justify-center gap-1">
            <div className="flex items-center gap-3">
              {/* Shuffle button (Secondary Muted Olive wash) */}
              <button
                onClick={() => setIsShuffle(!isShuffle)}
                className={`p-1.5 rounded-full transition-colors cursor-pointer text-[#443C35] ${
                  isShuffle ? 'bg-[#C99D9A] shadow-xs' : 'hover:bg-[#89977D]/15'
                }`}
                title="Shuffle Movements"
              >
                <Shuffle size={14} />
              </button>

              {/* Prev Movement */}
              <button
                onClick={onPrevTrack}
                className="p-1.5 rounded-full hover:bg-[#89977D]/15 text-[#443C35] transition-colors cursor-pointer"
                title="Previous Movement"
              >
                <SkipBack size={16} />
              </button>

              {/* Master Play Button: Solid Deep Forest (#485B4C) with Cream White (#FBF8F1) icon */}
              <button
                onClick={onPlayPause}
                disabled={!currentTrack}
                className="w-10 h-10 rounded-full flex items-center justify-center transition-all cursor-pointer shadow-sm active:scale-95 disabled:opacity-50"
                style={{
                  backgroundColor: '#485B4C',
                  color: '#FBF8F1',
                  boxShadow: '0 4px 12px rgba(72, 91, 76, 0.35)'
                }}
                title={isPlaying ? 'Pause' : 'Commence Movement'}
              >
                {isPlaying ? (
                  <Pause size={17} className="fill-[#FBF8F1]" />
                ) : (
                  <Play size={17} className="fill-[#FBF8F1] ml-0.5" />
                )}
              </button>

              {/* Next Movement */}
              <button
                onClick={onNextTrack}
                className="p-1.5 rounded-full hover:bg-[#89977D]/15 text-[#443C35] transition-colors cursor-pointer"
                title="Next Movement"
              >
                <SkipForward size={16} />
              </button>

              {/* Repeat button */}
              <button
                onClick={() => setIsRepeat(!isRepeat)}
                className={`p-1.5 rounded-full transition-colors cursor-pointer text-[#443C35] ${
                  isRepeat ? 'bg-[#89977D] text-[#FBF8F1] shadow-xs' : 'hover:bg-[#89977D]/15'
                }`}
                title="Repeat Movement"
              >
                <Repeat size={14} />
              </button>
            </div>

            {/* Time Stamp Display */}
            <div className="flex items-center gap-2 text-[11px] font-mono text-[#81776D] select-none">
              <span>{formatTime(currentTime)}</span>
              <span className="opacity-40">/</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Right: Master Volume & Audio Status */}
          <div className="flex items-center justify-end gap-3 min-w-[240px]">
            <div className="flex items-center gap-2">
              <button
                onClick={toggleMute}
                className="p-1 rounded-full hover:bg-[#89977D]/15 text-[#81776D] hover:text-[#443C35] transition-colors cursor-pointer"
                title={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted || volume === 0 ? <VolumeX size={15} /> : <Volume2 size={15} />}
              </button>
              
              {/* Volume Slider styled with warm terracotta and sage */}
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={isMuted ? 0 : volume}
                onChange={(e) => {
                  setIsMuted(false);
                  onVolumeChange(parseFloat(e.target.value));
                }}
                className="w-20 h-1 bg-[#EAE1D2] rounded-lg appearance-none cursor-pointer accent-[#55624b]"
                title={`Volume: ${Math.round(volume * 100)}%`}
              />
            </div>

            <div className="h-4 w-px bg-[#443C35]/15" />

            <button
              onClick={onOpenSpecimenModal}
              className="px-2.5 py-1 rounded-md text-[11px] font-sans text-[#443C35] bg-[#EAE1D2] hover:bg-[#A5B49A]/30 border border-[#443C35]/10 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Sparkles size={12} className="text-[#55624b]" />
              <span className="hidden sm:inline">Specimen Plate</span>
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
