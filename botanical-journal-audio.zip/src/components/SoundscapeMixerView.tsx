import React from 'react';
import { 
  Wind, 
  CloudRain, 
  Droplets, 
  BookOpen, 
  SunMedium, 
  Volume2, 
  VolumeX, 
  RotateCcw,
  Sparkles
} from 'lucide-react';
import { SoundscapeLayer } from '../types';

interface SoundscapeMixerViewProps {
  layers: SoundscapeLayer[];
  onToggleLayer: (layerId: string) => void;
  onChangeVolume: (layerId: string, volume: number) => void;
  onResetLayers: () => void;
  onApplyPreset: (presetName: string) => void;
}

export const SoundscapeMixerView: React.FC<SoundscapeMixerViewProps> = ({
  layers,
  onToggleLayer,
  onChangeVolume,
  onResetLayers,
  onApplyPreset,
}) => {
  const getIcon = (name: string) => {
    switch (name) {
      case 'wind':
        return <Wind size={18} />;
      case 'cloud-rain':
        return <CloudRain size={18} />;
      case 'droplets':
        return <Droplets size={18} />;
      case 'book-open':
        return <BookOpen size={18} />;
      case 'sun-medium':
        return <SunMedium size={18} />;
      default:
        return <Sparkles size={18} />;
    }
  };

  return (
    <div className="w-full max-w-[1200px] mx-auto py-8 px-6 lg:px-10 animate-fade-in space-y-8">
      {/* Header */}
      <div className="border-b border-[#443C35]/15 pb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <span className="text-xs font-mono uppercase tracking-widest text-[#89977D]">
            Botanical Atmosphere Generator • Continuous Resonance
          </span>
          <h2 className="font-serif text-3xl font-medium text-[#443C35] mt-1 tracking-tight">
            Soundscape Alchemist
          </h2>
          <p className="text-xs text-[#81776D] font-serif italic mt-1 max-w-xl">
            Synthesize layered organic field ambiances in real time. Combine wind, rain, water basins, and parchment rustle with your chosen chamber folios.
          </p>
        </div>

        <button
          onClick={onResetLayers}
          className="px-3 py-1.5 rounded-md text-xs text-[#81776D] hover:text-[#443C35] bg-[#EAE1D2] hover:bg-[#A5B49A]/30 border border-[#443C35]/10 flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <RotateCcw size={12} />
          <span>Reset Ambient Balance</span>
        </button>
      </div>

      {/* Preset Atmospheres */}
      <div className="paper-sheet p-5 rounded-lg space-y-3">
        <span className="text-[11px] font-mono uppercase tracking-wider text-[#81776D] block">
          Archival Environmental Presets
        </span>
        <div className="flex flex-wrap gap-2.5">
          {[
            { id: 'rainy-greenhouse', label: 'Rainy Greenhouse Afternoon', desc: 'Rain on glass + heavy damp wind' },
            { id: 'kyoto-calligraphy', label: 'Kyoto Washi Study Desk', desc: 'Paper rustle + temple water basin' },
            { id: 'alpine-canopy', label: 'Alpine Sanctuary Breeze', desc: 'Canopy wind + evening cicadas' },
            { id: 'all-clear', label: 'Quiet Room (Folio Only)', desc: 'Mute all nature layers' },
          ].map((preset) => (
            <button
              key={preset.id}
              onClick={() => onApplyPreset(preset.id)}
              className="px-3.5 py-2 rounded-lg text-xs text-[#443C35] bg-[#F5F0E6] hover:bg-[#89977D]/25 border border-[#443C35]/10 text-left transition-colors cursor-pointer"
            >
              <div className="font-serif font-medium">{preset.label}</div>
              <div className="text-[10px] text-[#81776D]">{preset.desc}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Sliders Grid for the 5 Layers */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {layers.map((layer) => {
          const isLayerActive = layer.enabled && layer.volume > 0.01;

          return (
            <div 
              key={layer.id}
              className={`paper-sheet rounded-lg p-5 flex flex-col justify-between transition-all duration-200 ${
                isLayerActive ? 'border-[#55624b]/40 shadow-sm' : 'opacity-85'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    <div 
                      className="w-8 h-8 rounded-full flex items-center justify-center transition-colors"
                      style={{
                        backgroundColor: isLayerActive ? layer.colorWash : '#EAE1D2',
                        color: isLayerActive ? '#FBF8F1' : '#81776D'
                      }}
                    >
                      {getIcon(layer.iconName)}
                    </div>
                    <div>
                      <h4 className="font-serif text-base font-medium text-[#443C35] leading-tight">
                        {layer.name}
                      </h4>
                      {layer.japaneseTitle && (
                        <span className="text-[11px] text-[#81776D] font-serif italic">
                          {layer.japaneseTitle}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Tactile toggle switch */}
                  <button
                    onClick={() => onToggleLayer(layer.id)}
                    className={`w-9 h-5 rounded-full transition-colors relative cursor-pointer ${
                      layer.enabled ? 'bg-[#55624b]' : 'bg-[#EAE1D2] border border-[#443C35]/15'
                    }`}
                    title={layer.enabled ? 'Mute Layer' : 'Activate Layer'}
                  >
                    <div 
                      className={`w-3.5 h-3.5 rounded-full bg-[#FBF8F1] transition-transform absolute top-0.5 shadow-2xs ${
                        layer.enabled ? 'translate-x-4.5' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>

                <p className="text-xs text-[#81776D] font-sans leading-relaxed min-h-[36px]">
                  {layer.description}
                </p>
              </div>

              {/* Volume Slider & Level Indicator */}
              <div className="mt-6 pt-4 border-t border-[#443C35]/10 space-y-2">
                <div className="flex items-center justify-between text-xs text-[#81776D] font-mono">
                  <span className="flex items-center gap-1.5">
                    {layer.enabled ? <Volume2 size={13} /> : <VolumeX size={13} />}
                    <span>Layer Pot</span>
                  </span>
                  <span>{Math.round((layer.enabled ? layer.volume : 0) * 100)}%</span>
                </div>

                <div className="relative flex items-center">
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.01"
                    value={layer.enabled ? layer.volume : 0}
                    onChange={(e) => {
                      onChangeVolume(layer.id, parseFloat(e.target.value));
                    }}
                    className="w-full h-1.5 bg-[#EAE1D2] rounded-lg appearance-none cursor-pointer accent-[#55624b]"
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
