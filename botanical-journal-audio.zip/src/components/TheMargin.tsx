import React from 'react';
import { 
  BookOpen, 
  Library, 
  Sliders, 
  Feather, 
  Sparkles, 
  Search,
  Compass,
  ChevronLeft,
  ChevronRight,
  Bookmark
} from 'lucide-react';
import { ActiveView } from '../types';
import { SHELVES, FILTER_TAGS } from '../data/botanicalData';

interface TheMarginProps {
  activeView: ActiveView;
  setActiveView: (view: ActiveView) => void;
  selectedShelf: string;
  setSelectedShelf: (shelf: string) => void;
  selectedTag: string;
  setSelectedTag: (tag: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  isCollapsed: boolean;
  setIsCollapsed: (collapsed: boolean) => void;
  currentAlbumTitle: string;
  totalNotesCount: number;
}

export const TheMargin: React.FC<TheMarginProps> = ({
  activeView,
  setActiveView,
  selectedShelf,
  setSelectedShelf,
  selectedTag,
  setSelectedTag,
  searchQuery,
  setSearchQuery,
  isCollapsed,
  setIsCollapsed,
  totalNotesCount,
}) => {
  if (isCollapsed) {
    return (
      <aside 
        className="w-16 h-full flex flex-col items-center py-6 border-r border-[#443C35]/10 bg-[#EAE1D2] transition-all duration-300 select-none z-20 shrink-0"
        title="Expand Margin"
      >
        <button
          onClick={() => setIsCollapsed(false)}
          className="p-2.5 rounded-full hover:bg-[#89977D]/20 text-[#443C35] transition-colors mb-6 cursor-pointer"
          title="Expand Botanical Folio"
        >
          <ChevronRight size={18} />
        </button>

        <div className="flex flex-col gap-5 items-center">
          <button
            onClick={() => { setActiveView('journal'); setIsCollapsed(false); }}
            className={`p-2.5 rounded-lg transition-colors cursor-pointer ${
              activeView === 'journal' ? 'bg-[#55624b] text-[#FBF8F1]' : 'text-[#81776D] hover:bg-[#89977D]/15'
            }`}
            title="The Leaf (Field Journal)"
          >
            <BookOpen size={18} />
          </button>
          <button
            onClick={() => { setActiveView('herbarium'); setIsCollapsed(false); }}
            className={`p-2.5 rounded-lg transition-colors cursor-pointer ${
              activeView === 'herbarium' ? 'bg-[#55624b] text-[#FBF8F1]' : 'text-[#81776D] hover:bg-[#89977D]/15'
            }`}
            title="The Herbarium (Compendiums)"
          >
            <Library size={18} />
          </button>
          <button
            onClick={() => { setActiveView('soundscape'); setIsCollapsed(false); }}
            className={`p-2.5 rounded-lg transition-colors cursor-pointer ${
              activeView === 'soundscape' ? 'bg-[#55624b] text-[#FBF8F1]' : 'text-[#81776D] hover:bg-[#89977D]/15'
            }`}
            title="Soundscape Alchemist"
          >
            <Sliders size={18} />
          </button>
          <button
            onClick={() => { setActiveView('marginalia'); setIsCollapsed(false); }}
            className={`p-2.5 rounded-lg transition-colors cursor-pointer relative ${
              activeView === 'marginalia' ? 'bg-[#55624b] text-[#FBF8F1]' : 'text-[#81776D] hover:bg-[#89977D]/15'
            }`}
            title="Marginalia & Seals"
          >
            <Feather size={18} />
            {totalNotesCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#B97862] text-[9px] text-[#FBF8F1] flex items-center justify-center font-serif">
                {totalNotesCount}
              </span>
            )}
          </button>
        </div>

        <div className="mt-auto writing-mode-vertical text-[11px] tracking-widest uppercase text-[#81776D] opacity-60 font-serif pt-4 select-none">
          FOLIO 1894
        </div>
      </aside>
    );
  }

  return (
    <aside className="w-[280px] h-full flex flex-col border-r border-[#443C35]/10 bg-[#EAE1D2] select-none z-20 shrink-0 transition-all duration-300">
      {/* Top Header / Header Seal */}
      <div className="p-5 pb-4 border-b border-[#443C35]/10 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-[#55624b] text-[#FBF8F1] flex items-center justify-center shadow-xs">
            <Sparkles size={16} />
          </div>
          <div>
            <h1 className="font-serif text-lg font-medium leading-none tracking-tight text-[#443C35]">
              Botanical Audio
            </h1>
            <p className="text-[11px] text-[#81776D] tracking-wider uppercase mt-1">
              Herbarium & Folios
            </p>
          </div>
        </div>
        <button
          onClick={() => setIsCollapsed(true)}
          className="p-1.5 rounded-full hover:bg-[#89977D]/15 text-[#81776D] hover:text-[#443C35] transition-colors cursor-pointer"
          title="Collapse Margin"
        >
          <ChevronLeft size={16} />
        </button>
      </div>

      {/* Ledger Search Input */}
      <div className="px-5 pt-4 pb-2">
        <div className="relative">
          <Search size={14} className="absolute left-1 top-2.5 text-[#81776D]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search specimens, keys, folios..."
            className="w-full pl-6 pr-2 py-1.5 text-xs text-[#443C35] ledger-input placeholder:text-[#81776D]/60 placeholder:font-serif"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-1 top-2 text-[10px] text-[#81776D] hover:text-[#B97862] cursor-pointer"
            >
              clear
            </button>
          )}
        </div>
      </div>

      {/* Main Navigation Desks */}
      <div className="px-3 py-3 border-b border-[#443C35]/10">
        <div className="text-[10px] uppercase font-semibold text-[#81776D] tracking-wider px-2 mb-1.5 flex items-center gap-1.5">
          <Compass size={11} /> Primary Desks
        </div>
        <nav className="flex flex-col gap-1">
          <button
            onClick={() => setActiveView('journal')}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm text-left transition-colors cursor-pointer ${
              activeView === 'journal'
                ? 'bg-[#FBF8F1] text-[#211a14] font-medium shadow-xs border border-[#443C35]/10'
                : 'text-[#443C35]/80 hover:bg-[#FBF8F1]/60'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <BookOpen size={15} className={activeView === 'journal' ? 'text-[#55624b]' : 'text-[#81776D]'} />
              <span>The Leaf (Field Journal)</span>
            </span>
            <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-[#89977D]/15 text-[#55624b] font-mono">
              Op. IV
            </span>
          </button>

          <button
            onClick={() => setActiveView('herbarium')}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm text-left transition-colors cursor-pointer ${
              activeView === 'herbarium'
                ? 'bg-[#FBF8F1] text-[#211a14] font-medium shadow-xs border border-[#443C35]/10'
                : 'text-[#443C35]/80 hover:bg-[#FBF8F1]/60'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <Library size={15} className={activeView === 'herbarium' ? 'text-[#55624b]' : 'text-[#81776D]'} />
              <span>The Herbarium (Shelves)</span>
            </span>
            <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-[#EAE1D2] text-[#81776D] font-mono">
              5
            </span>
          </button>

          <button
            onClick={() => setActiveView('soundscape')}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm text-left transition-colors cursor-pointer ${
              activeView === 'soundscape'
                ? 'bg-[#FBF8F1] text-[#211a14] font-medium shadow-xs border border-[#443C35]/10'
                : 'text-[#443C35]/80 hover:bg-[#FBF8F1]/60'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <Sliders size={15} className={activeView === 'soundscape' ? 'text-[#55624b]' : 'text-[#81776D]'} />
              <span>Soundscape Alchemist</span>
            </span>
            <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-[#B6C9D2]/25 text-[#443C35] font-mono">
              Live
            </span>
          </button>

          <button
            onClick={() => setActiveView('marginalia')}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm text-left transition-colors cursor-pointer ${
              activeView === 'marginalia'
                ? 'bg-[#FBF8F1] text-[#211a14] font-medium shadow-xs border border-[#443C35]/10'
                : 'text-[#443C35]/80 hover:bg-[#FBF8F1]/60'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <Feather size={15} className={activeView === 'marginalia' ? 'text-[#55624b]' : 'text-[#81776D]'} />
              <span>Listener Marginalia</span>
            </span>
            {totalNotesCount > 0 && (
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-[#B97862]/20 text-[#B97862] font-mono">
                {totalNotesCount}
              </span>
            )}
          </button>
        </nav>
      </div>

      {/* Shelves & Collections List */}
      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4">
        <div>
          <div className="text-[10px] uppercase font-semibold text-[#81776D] tracking-wider px-1 mb-2 flex items-center gap-1.5">
            <Bookmark size={11} /> Botanical Shelves
          </div>
          <div className="space-y-1">
            {SHELVES.map((shelf) => {
              const isActive = selectedShelf === shelf.id;
              return (
                <button
                  key={shelf.id}
                  onClick={() => {
                    setSelectedShelf(shelf.id);
                    if (activeView !== 'herbarium' && activeView !== 'journal') {
                      setActiveView('herbarium');
                    }
                  }}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-xs text-left transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-[#89977D]/20 text-[#211a14] font-medium'
                      : 'text-[#443C35]/75 hover:bg-[#FBF8F1]/40'
                  }`}
                >
                  <span className="truncate pr-2">{shelf.name}</span>
                  <span className="text-[10px] text-[#81776D] font-mono">{shelf.count}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Parchment Tag Marks */}
        <div>
          <div className="text-[10px] uppercase font-semibold text-[#81776D] tracking-wider px-1 mb-2">
            Parchment Tag Marks
          </div>
          <div className="flex flex-wrap gap-1.5">
            {FILTER_TAGS.map((tag) => {
              const isSelected = selectedTag === tag || (tag === 'All Instrumentation' && selectedTag === '');
              return (
                <button
                  key={tag}
                  onClick={() => setSelectedTag(tag === 'All Instrumentation' ? '' : tag)}
                  className={`px-2.5 py-1 rounded-full text-[11px] font-sans transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#B7A8C8] text-[#443C35] font-medium shadow-2xs'
                      : 'bg-[#FBF8F1] text-[#81776D] border border-[#443C35]/10 hover:border-[#443C35]/25'
                  }`}
                >
                  {tag}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Curator Archival Stamp Footer */}
      <div className="p-3.5 border-t border-[#443C35]/10 bg-[#EAE1D2]/80 text-[11px] text-[#81776D] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded-full border border-[#81776D]/40 flex items-center justify-center font-serif text-[10px] text-[#55624b]">
            𐚚
          </div>
          <span className="font-serif italic text-xs text-[#443C35]/80">
            Linnaean Society No. 448
          </span>
        </div>
        <span className="text-[10px] uppercase tracking-widest text-[#81776D]/70 font-mono">
          KYOTO 1894
        </span>
      </div>
    </aside>
  );
};
